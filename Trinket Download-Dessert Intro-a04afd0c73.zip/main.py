a=input("What is your favorite flavor of cake?")
b=input("What is your favorite flavor of ice cream?")
if a==b:
 print("Good for you")
else:
  print("Ok...Good for you")
